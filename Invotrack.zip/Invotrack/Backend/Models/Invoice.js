// models/Invoice.js
const mongoose = require('mongoose');

const invoiceSchema = new mongoose.Schema({
  receiptId: {
    type: String,
    unique: true, // Ensure the receipt ID is unique
    required: true, // Make it mandatory
  },
  customerName: String,
  phoneNumber: String,
  email: String,
  address: String,
  products: [
    {
      productName: String,
      quantity: Number,
      amount: Number,
      tax: Number,
      total: Number,
    },
  ],
  totalAmount: Number,
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Invoice', invoiceSchema);
